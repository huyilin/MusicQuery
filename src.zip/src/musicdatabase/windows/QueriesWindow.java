package musicdatabase.windows;

import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import musicdatabase.Connector;

public class QueriesWindow extends javax.swing.JFrame {
	
	Statement statement;
	Connector connector = new Connector();
	String queryToRun;
	String query;
	
    public QueriesWindow() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textQuery = new javax.swing.JTextField();
        RunButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel1.setText("Run Queries");

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        jLabel2.setText("Query");

        RunButton.setText("RUN");
        RunButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	RunButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel2)
                        .addGap(26, 26, 26)
                        .addComponent(textQuery, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(RunButton, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jLabel1)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textQuery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RunButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void RunButtonActionPerformed(java.awt.event.ActionEvent evt) {
    	queryToRun = textQuery.getText();
    	ResultSet resultSet = null;
    	
    	DefaultTableModel model = new DefaultTableModel();
    	
    	if(queryToRun.equals("a") || queryToRun.equals("A")) {
        	model.addColumn("Artist Name");
    		query = "SELECT artist.ArtistName FROM area, artist " +
    				"WHERE area.IDArea=artist.IDArea AND area.areaName = 'Switzerland'";
    		try {
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("ArtistName")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("b") || queryToRun.equals("B")) {
        	model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
        	
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("c") || queryToRun.equals("C")) {
    		model.addColumn("Groups");
    		
    		query = "SELECT artistName FROM artist JOIN artist_track using(IDArtist) " +
					"WHERE type='group' GROUP BY ArtistName,IDArtist ORDER BY count(*) desc limit 10;";

    		try {
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("artistName")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("d") || queryToRun.equals("D")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("e") || queryToRun.equals("E")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("f") || queryToRun.equals("F")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("g") || queryToRun.equals("G")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("h") || queryToRun.equals("H")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("i") || queryToRun.equals("I")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("j") || queryToRun.equals("J")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("k") || queryToRun.equals("K")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("l") || queryToRun.equals("L")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("m") || queryToRun.equals("M")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("n") || queryToRun.equals("N")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("o") || queryToRun.equals("O")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("p") || queryToRun.equals("P")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("q") || queryToRun.equals("Q")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("r") || queryToRun.equals("R")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else if (queryToRun.equals("s") || queryToRun.equals("S")) {
    		model.addColumn("Area Name");
        	model.addColumn("Type");
        	model.addColumn("Number of artists");
    		String query1 = "set @a=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='female' " +
    						"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query2 = "set @b=(SELECT IDArea FROM area NATURAL JOIN artist WHERE gender='male' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		String query3 = "set @c=(SELECT IDArea FROM area NATURAL JOIN artist WHERE type='group' " +
							"GROUP BY IDArea ORDER BY count(*) desc limit 1);";
    		query = "SELECT areaName, type, count(*) FROM area NATURAL JOIN artist WHERE " +
					"IDArea=@a OR IDArea=@b OR IDArea=@c GROUP BY IDArea,type ORDER BY IDArea;";
    		try {
    			Statement statement1 = connector.getConnection().createStatement();
    			statement1.executeQuery(query1);
    			Statement statement2 = connector.getConnection().createStatement();
    			statement2.executeQuery(query2);
    			Statement statement3 = connector.getConnection().createStatement();
    			statement3.executeQuery(query3);
    			statement = connector.getConnection().createStatement();
    			resultSet = statement.executeQuery(query);
    			
    			while(resultSet.next()) {
    				model.addRow(new Object[] {resultSet.getString("areaName"),
    										   resultSet.getString("Type"),
    										   resultSet.getString("count(*)")});
    			}
    		} catch (SQLException sqle) {
                System.err.println(sqle);
            } finally {
                try {
                    statement.close();
                    resultSet.close();
                } catch (SQLException sqle) {
                    System.err.println(sqle);
                }
            }
    		
    		JTable resultTable = new JTable(model);
    		JOptionPane.showMessageDialog(null, new JScrollPane(resultTable));
    		
    	} else {
    		JOptionPane.showMessageDialog(null, "Available queries are A to S (a to s)!", "Error", JOptionPane.ERROR_MESSAGE);
    	}
    	
    	
    	//statement = connector.getConnection().createStatement();
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QueriesWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QueriesWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QueriesWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QueriesWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QueriesWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton RunButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField textQuery;
    // End of variables declaration//GEN-END:variables
}
